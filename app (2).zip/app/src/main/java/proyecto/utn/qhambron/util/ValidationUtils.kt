package proyecto.utn.qhambron.util

import android.content.Context
import android.content.Intent

/**
 * Utility class providing helper functions for common operations.
 * Includes methods for activity navigation and helper utilities.
 */
class ValidationUtils {

    companion object {

        fun openActivity(
            context: Context,
            activityClass: Class<*>
        ) {
            val intent = Intent(context, activityClass)
            context.startActivity(intent)
        }
    }
}